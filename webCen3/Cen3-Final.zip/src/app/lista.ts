

export class
  Lista {
    id:string;
    album:string;
    foto:string;
    nome: string;
    audio: {};

}
