
import{User} from './usuario';


export const USUARIOS: User[] = [


{
  
  email:"emilio.falcao@gmail.com",
  confemail:"emilio.falcao@gmail.com",
  senha:"123456",
  nome:"Emilio Falcão",
  dataNasc:"20201201",
  sexo:"M",
}

];

