
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Lista } from '../lista';
import{PlayLista} from '../mock-musicas';



@Injectable({
  providedIn: 'root'
})
export class PlaylistService {


  constructor() {

  }
  
}


