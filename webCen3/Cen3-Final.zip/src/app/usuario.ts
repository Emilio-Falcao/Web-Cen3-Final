

export class User {

  
  email:string;
  confemail:string;
  senha:string;
  nome:string;
  dataNasc:string;
  sexo:string;

}





