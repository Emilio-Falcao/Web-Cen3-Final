export const environment = {
  production: true
};
const firebaseConfig = {

};